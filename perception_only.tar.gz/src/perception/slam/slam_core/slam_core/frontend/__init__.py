"""Visual odometry frontend."""
