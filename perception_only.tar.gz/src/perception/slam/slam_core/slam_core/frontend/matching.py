"""Descriptor matching."""
